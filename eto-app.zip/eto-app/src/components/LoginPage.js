import React, { FC, memo, useState, useEffect } from 'react';
import axios from 'axios';
import { Route } from 'react-router';
import home from "../components/home"
const passwordRegex = new RegExp(
    "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,32})"
  );
const LoginPage = ()  => {
    const [username,setUsername] = useState("")
    const [password, setPassword] = useState("")
    const [confirmpassword, setConfirmpassword] = useState("")
    const [login, setLogin] = useState(true)
    const [firstName,setfirstName] = useState("")
    const [lastName,setLastName] = useState("")
    const [emailId,setemailId] = useState("")
    const [address,setAddress] = useState("")
    const [phonenumber,setPhonenumber] = useState("")
    const [Gender,setGender] = useState("")


    const hanleuserName = (value)=> {
        console.log(value,"valuechange");
        setUsername(value)
    }

    const handlePassword = (value) =>{
        
        console.log(value,"passwordchange")
        setPassword(value)
    }

    const handleSubmit = async() =>{
        if(passwordRegex.test(password)){
            let data = {username:username,password:password}
            let output  = await axios.post('http://localhost:8000/api/login',data)
            let response = JSON.stringify(output.data)
            alert(response.message)
            if(response.status){
                this.history.push('/home')
            }
        }
        else {
            alert(" please enter alphanumeric password")
        }
       
    }

    const handleRegister = async() =>{
        if(password === confirmpassword){
    if(passwordRegex.test(password)){
        let data = {firstName: firstName,
            lastName: lastName,
            password: password,
            address:address,
            username:username,
            phonenumber:phonenumber,
            emailId:emailId,
            Gender:Gender
            }
        let output  = await axios.post('http://localhost:8000/api/register',data)
        alert(JSON.stringify(output.data))
    }
    else {
        alert(" please enter alphanumeric password")
    }
}
else{
    alert("Please check password and confirmpassword should be equal")
}
}

    return (
        
        <>
       
        <div className='col-md-12 row'>
            <div className='col-md-4'></div>
            {login ? (<div className='col-md-4 '>
                <h2>Login</h2>
                <div>
                  <span style={{paddingRight:"10px"}}>User Name</span>  
                <input id="username" type="text" placeholder='user name' value={username} onChange={(e)=>hanleuserName(e.target.value)} required/>
                </div>
                
                <div>
                <span style={{paddingRight:"25px"}}>password</span>
                <input id="username" type="password" placeholder='password' value={password} onChange={(e)=>handlePassword(e.target.value)} required/>
                </div>
                <div >
                <button onClick={()=>handleSubmit()} style={{cursor:"pointer"}}>Sign in</button>
                <button onClick={()=>setLogin(false)} style={{cursor:"pointer"}}>Sign Up</button>
                </div>
                
            </div>):(<div className='col-md-4 '>
                <h2>Register</h2>
                <div>
                  <span style={{paddingRight:"10px"}}>User Name</span>  
                <input id="username" type="text" placeholder='user name' value={username} onChange={(e)=>hanleuserName(e.target.value)} required/>
                </div>
                
                <div>
                <span style={{textAlign:"right"}}>password</span>
                <input id="password" type="password" placeholder='password' value={password} onChange={(e)=>handlePassword(e.target.value)} minlength="8" required/>
                </div>
                <div>
                <span style={{textAlign:"left"}}>confirmpassword</span>
                <input id="confirmpassword" type="password" placeholder='password' value={confirmpassword} onChange={(e)=>setConfirmpassword(e.target.value)} required/>
                </div>
                <div >
                <div>
                <span style={{paddingRight:"25px"}}>firstName</span>
                <input id="firstName" type="text" placeholder='firstName' value={firstName} onChange={(e)=>setfirstName(e.target.value)} minlength="8" required/>
                </div>
                <div>
                <span style={{paddingRight:"25px"}}>lastName</span>
                <input id="lastName" type="text" placeholder='lastName' value={lastName} onChange={(e)=>setLastName(e.target.value)} minlength="8" required/>
                </div>
                <div>
                <span style={{paddingRight:"25px"}}>Address</span>
                <input id="address" type="text" placeholder='address' value={address} onChange={(e)=>setAddress(e.target.value)} minlength="8" required/>
                </div>
                <div>
                <span style={{paddingRight:"25px"}}>phonenumber</span>
                <input id="phonenumber" type="number" placeholder='phonenumber' value={phonenumber} onChange={(e)=>setPhonenumber(e.target.value)} maxLength={10} required/>
                </div>
                <div>
                <span style={{paddingRight:"25px"}}>emailId</span>
                <input id="emailId" type="email" placeholder='emailId' value={emailId} onChange={(e)=>setemailId(e.target.value)} minlength="8" required/>
                </div>
                <div>
                <span style={{paddingRight:"25px"}}>Gender</span>
                <input id="Gender" type="text" placeholder='Gender' value={Gender} onChange={(e)=>setGender(e.target.value)} minlength="8" required/>
                </div>
                <button onClick={()=>handleRegister()} style={{cursor:"pointer"}}>Create Account</button>
                <a href="Login" onClick={()=>setLogin(true)} style={{cursor:"pointer"}}>Login</a>
                </div>
                
            </div>)}
            <div className='col-md-4'></div>
        </div>
        </>
    )
}
export default LoginPage; 