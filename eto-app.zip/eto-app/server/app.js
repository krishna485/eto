var express = require('express')
var app = express();
let cors = require("cors")
var bodyParser = require('body-parser');
const mongodb = require('mongodb');
const MongoClient = mongodb.MongoClient;
// Connection URL
const url = 'mongodb://localhost:27017';

// Database Name
const dbName = 'eto';

let db = MongoClient.connect(url, (err, client) => {
    if (err) {
        throw err;
        return;
    }

    console.log('Database connection successful');

    // This objects holds the refrence to the db
     return db = client.db(dbName);

    client.close();
});


app.use(bodyParser.urlencoded({ extended: false }))

// parse application/json

app.use(bodyParser.json())
app.get('/', function (req, res) {
  res.send('hello world')
})
app.get("/api/test",function(req, res){
  console.log("in test");
res.send("welcome Be")
})

app.post("/api/login",cors() ,async function(req, res){
  console.log("in test",req.body);
  const collection = db.collection('users');

// Insert one document
let output = await collection.findOne({
    username:req.body.username
})
    
    console.log(output);
  if(!output){
    res.send("Couldn't find your record, Please signUp")
  }
  else if(req.body.password === output.password){
    res.send({message : "welcome" + req.body.username, status: 200})
  }  
  else{
    res.send("Please check your password")
  }
    
})

app.post("/api/register",cors() ,async function(req, res){
  console.log("in test",req.body);
  const collection = db.collection('users');

// Insert one document
let output = await collection.insertOne({
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    password: req.body.password,
    address:req.body.address,
    username:req.body.username,
    phonenumber:req.body.phonenumber,
    emailId:req.body.emailId,
    Gender:req.body.Gender
}, (err, result) => {
    if (err) {
        console.log(err);
        res.send("Registration Failed, Try After Some Time")
    }
    
    else {
      res.send("Registration Successfull")
    }
});


  
})
app.use(function (req, res, next) {

  // Website you wish to allow to connect
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:3000');

  // Request methods you wish to allow
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

  // Request headers you wish to allow
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

  // Set to true if you need the website to include cookies in the requests sent
  // to the API (e.g. in case you use sessions)
  res.setHeader('Access-Control-Allow-Credentials', false);

  // Pass to next layer of middleware
  next();
});
app.listen(8000)