var db = require('../app')
const collection = db.collection('users');

// Insert one document

const registerFunction = async(req) => {
    let output = await collection.insertOne({
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        password: req.body.password,
        address:req.body.address,
        username:req.body.username,
        phonenumber:req.body.phonenumber,
        emailId:req.body.emailId,
        Gender:req.body.Gender
    });
    return output;
}

module.exports = registerFunction;
